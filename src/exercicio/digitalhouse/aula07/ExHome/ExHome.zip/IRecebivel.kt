package exercicio.digitalhouse.aula07.ExHome

interface IRecebivel {

    fun totalizarReceita(): Double
    override fun toString(): String

}
